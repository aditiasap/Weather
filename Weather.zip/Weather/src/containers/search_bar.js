import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { fetchWeather } from '../actions/index';

class SearchBar extends Component {
	constructor(props) {
		super(props);
		
		this.state = { term: '' };
		
		// If we do callback like onInputChange, and inside onInputChange function calls to this which refer to component (will get mystery context),
		// and not doing '()=>onInputChange()' format like previously in YTSearch,
		// Then do bind like below. It will override existing onInputChange with bound one
		this.onInputChange = this.onInputChange.bind(this);
		this.onFormSubmit = this.onFormSubmit.bind(this);
	}
	
	onInputChange(event) {
		//console.log(event.target.value);
		this.setState({ term: event.target.value });
	}
	
	onFormSubmit(event) {
		// Prevent submit POST data to server as default behaviour
		event.preventDefault();
		
		// We need to go and fetch weather data
		this.props.fetchWeather(this.state.term);
		this.setState({ term: '' });
	}
	
	render() {
		return (
			// To prevent Submit button inside <form> to submit POST data to server when it is clicked or enter (as default behaviour of form button), form need to be handled. with preventDefault().
			// We use <form> instead of <div>, because with <form>, we get free functionalities like when user hit enter on input, it will automatically click submit without need extra handling.
			<form onSubmit={this.onFormSubmit} className="input-group">
				<input
					placeholder="Give a five-day forecast in your favorite city"
					className="form-control"
					value={this.state.term}
					onChange={this.onInputChange} />
				<span className="input-group-btn">
					<button type="submit" className="btn btn-secondary">Submit</button>
				</span>
			</form>
		);
	}
}

function mapDispatchToProps(dispatch) {
	return bindActionCreators({ fetchWeather }, dispatch);
}

export default connect(null, mapDispatchToProps)(SearchBar);