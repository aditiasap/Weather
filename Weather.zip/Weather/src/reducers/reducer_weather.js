import { FETCH_WEATHER } from '../actions/index';

export default function(state = [], action) {
	// console.log('Action received', action);
	switch (action.type) {
		case FETCH_WEATHER:
			// replace current active city. This is not we want. We want to add city into an array
			// return [ action.payload.data ];
			
			// Add current city into the array. But push will override existing array. It is prohibited in flux/redux architecture, which says 'never mutate the state directly'
			// return state.push(action.payload.data);
			
			// concat is creating new array instead of mutating existing array
			// return state.concat([action.payload.data]);
			
			// ES6 style that nearly identical to concat above.
			// It said, create new array that filled by action.payload.data, then put existing data inside state array into that newly array instance.
			// Will result in [ city, city, city ].
			// NOT [ city, [city, city] ].
			return [ action.payload.data, ...state ];
	}
	return state;
}